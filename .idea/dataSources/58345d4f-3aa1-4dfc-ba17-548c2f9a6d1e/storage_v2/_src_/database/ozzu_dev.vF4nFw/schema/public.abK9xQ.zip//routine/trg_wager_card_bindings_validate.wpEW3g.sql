create function trg_wager_card_bindings_validate() returns trigger
    language plpgsql
as
$$
DECLARE
    v_wager_event_id uuid;
    v_wctb_concept_term_id uuid;
    v_sr_event_id uuid;
    v_sr_concept_term_id uuid;
BEGIN
    SELECT wc.wager_event_id
    INTO v_wager_event_id
    FROM wager_cards wc
    WHERE wc.id = NEW.wager_card_id;

    IF v_wager_event_id IS NULL THEN
        RAISE EXCEPTION
            'Invalid wager_card_id %, cannot resolve wager/event',
            NEW.wager_card_id
            USING ERRCODE = '23503';
    END IF;

    SELECT wctb.concept_term_id
    INTO v_wctb_concept_term_id
    FROM wager_card_type_bindings wctb
    WHERE wctb.id = NEW.wager_card_type_binding_id;

    IF v_wctb_concept_term_id IS NULL THEN
        RAISE EXCEPTION
            'Invalid wager_card_type_binding_id %, cannot resolve concept_term_id',
            NEW.wager_card_type_binding_id
            USING ERRCODE = '23503';
    END IF;

    IF NEW.scoped_referent_id IS NOT NULL THEN
        SELECT sr.event_id, sr.concept_term_id
        INTO v_sr_event_id, v_sr_concept_term_id
        FROM scoped_referents sr
        WHERE sr.id = NEW.scoped_referent_id;

        IF v_sr_event_id IS NULL THEN
            RAISE EXCEPTION 'Invalid scoped_referent_id %', NEW.scoped_referent_id
                USING ERRCODE = '23503';
        END IF;

        IF v_sr_event_id <> v_wager_event_id THEN
            RAISE EXCEPTION
                'Scoped referent % belongs to event %, but wager is for event %',
                NEW.scoped_referent_id, v_sr_event_id, v_wager_event_id
                USING ERRCODE = '23514';
        END IF;

        IF v_sr_concept_term_id <> v_wctb_concept_term_id THEN
            RAISE EXCEPTION
                'Scoped referent concept_term_id % does not match expected concept_term_id % for wager_card_type_binding_id %',
                v_sr_concept_term_id, v_wctb_concept_term_id, NEW.wager_card_type_binding_id
                USING ERRCODE = '23514';
        END IF;

        RETURN NEW;
    END IF;

    IF NEW.player_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM event_participants ep
            WHERE ep.event_id = v_wager_event_id AND ep.player_id = NEW.player_id
        ) THEN
            RAISE EXCEPTION
                'Picked player_id % is not an event participant for wager event_id %',
                NEW.player_id, v_wager_event_id
                USING ERRCODE = '23514';
        END IF;
    END IF;

    IF NEW.team_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM event_participants ep
            WHERE ep.event_id = v_wager_event_id AND ep.team_id = NEW.team_id
        ) THEN
            RAISE EXCEPTION
                'Picked team_id % is not an event participant for wager event_id %',
                NEW.team_id, v_wager_event_id
                USING ERRCODE = '23514';
        END IF;
    END IF;

    RETURN NEW;
END$$;

alter function trg_wager_card_bindings_validate() owner to postgres;

