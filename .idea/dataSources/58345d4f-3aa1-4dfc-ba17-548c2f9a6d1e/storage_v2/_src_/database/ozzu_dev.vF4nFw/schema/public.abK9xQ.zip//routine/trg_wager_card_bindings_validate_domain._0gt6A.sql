create function trg_wager_card_bindings_validate_domain() returns trigger
    language plpgsql
as
$$
DECLARE
    v_wager_event_id uuid;
    v_wager_id uuid;
    v_wager_domain_id uuid;
    v_event_domain_id uuid;
    v_sr_domain_id uuid;
    v_player_domain uuid;
    v_team_domain uuid;
BEGIN
    -- Resolve wager_event_id + wager_id from wager_cards
    SELECT wc.wager_event_id, wc.wager_id
    INTO v_wager_event_id, v_wager_id
    FROM wager_cards wc
    WHERE wc.id = NEW.wager_card_id;

    IF v_wager_event_id IS NULL OR v_wager_id IS NULL THEN
        RAISE EXCEPTION 'Invalid wager_card_id %, cannot resolve wager/event keys',
            NEW.wager_card_id USING ERRCODE = '23503';
    END IF;

    -- Resolve wager domain via composite join to wagers
    SELECT w.domain_id
    INTO v_wager_domain_id
    FROM wagers w
    WHERE w.event_id = v_wager_event_id AND w.id = v_wager_id;

    IF v_wager_domain_id IS NULL THEN
        RAISE EXCEPTION 'Cannot resolve wager (event_id %, id %) from wager_card_id %',
            v_wager_event_id, v_wager_id, NEW.wager_card_id USING ERRCODE = '23503';
    END IF;

    SELECT e.domain_id INTO v_event_domain_id
    FROM events e
    WHERE e.id = v_wager_event_id;

    IF v_event_domain_id IS NULL THEN
        RAISE EXCEPTION 'Invalid event_id % (from wager_card)', v_wager_event_id USING ERRCODE = '23503';
    END IF;

    IF v_event_domain_id <> v_wager_domain_id THEN
        RAISE EXCEPTION
            'Wager domain_id % does not match event domain_id % (event_id %)',
            v_wager_domain_id, v_event_domain_id, v_wager_event_id
            USING ERRCODE = '23514';
    END IF;

    IF NEW.scoped_referent_id IS NOT NULL THEN
        SELECT sr.domain_id INTO v_sr_domain_id
        FROM scoped_referents sr
        WHERE sr.id = NEW.scoped_referent_id;

        IF v_sr_domain_id IS NULL THEN
            RAISE EXCEPTION 'Invalid scoped_referent_id %', NEW.scoped_referent_id
                USING ERRCODE = '23503';
        END IF;

        IF v_sr_domain_id <> v_wager_domain_id THEN
            RAISE EXCEPTION
                'Scoped referent domain_id % does not match wager/event domain_id %',
                v_sr_domain_id, v_wager_domain_id
                USING ERRCODE = '23514';
        END IF;

        RETURN NEW;
    END IF;

    IF NEW.player_id IS NOT NULL THEN
        SELECT p.domain_id INTO v_player_domain FROM players p WHERE p.id = NEW.player_id;
        IF v_player_domain IS NULL THEN
            RAISE EXCEPTION 'Invalid player_id %', NEW.player_id USING ERRCODE = '23503';
        END IF;
        IF v_player_domain <> v_wager_domain_id THEN
            RAISE EXCEPTION
                'Picked player domain_id % does not match wager/event domain_id %',
                v_player_domain, v_wager_domain_id
                USING ERRCODE = '23514';
        END IF;
    END IF;

    IF NEW.team_id IS NOT NULL THEN
        SELECT t.domain_id INTO v_team_domain FROM teams t WHERE t.id = NEW.team_id;
        IF v_team_domain IS NULL THEN
            RAISE EXCEPTION 'Invalid team_id %', NEW.team_id USING ERRCODE = '23503';
        END IF;
        IF v_team_domain <> v_wager_domain_id THEN
            RAISE EXCEPTION
                'Picked team domain_id % does not match wager/event domain_id %',
                v_team_domain, v_wager_domain_id
                USING ERRCODE = '23514';
        END IF;
    END IF;

    RETURN NEW;
END$$;

alter function trg_wager_card_bindings_validate_domain() owner to postgres;

