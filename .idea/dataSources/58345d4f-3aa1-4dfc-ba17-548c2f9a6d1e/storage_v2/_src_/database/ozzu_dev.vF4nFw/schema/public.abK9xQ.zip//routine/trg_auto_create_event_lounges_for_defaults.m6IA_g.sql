create function trg_auto_create_event_lounges_for_defaults() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO event_lounges (
        id, domain_id, lounge_id, event_id, entry_fee_tokens, is_active, internal_properties, created_at, updated_at
    )
    SELECT
        gen_random_uuid(),
        NEW.domain_id,
        l.id,
        NEW.id,
        0,
        true,
        jsonb_build_object('autoCreated', true, 'seedVersion','v1'),
        now(),
        now()
    FROM lounges l
    WHERE l.domain_id = NEW.domain_id
      AND COALESCE((l.internal_properties->>'isDefault')::boolean, false) = true
    ON CONFLICT (lounge_id, event_id) DO NOTHING;

    RETURN NEW;
END;
$$;

alter function trg_auto_create_event_lounges_for_defaults() owner to postgres;

