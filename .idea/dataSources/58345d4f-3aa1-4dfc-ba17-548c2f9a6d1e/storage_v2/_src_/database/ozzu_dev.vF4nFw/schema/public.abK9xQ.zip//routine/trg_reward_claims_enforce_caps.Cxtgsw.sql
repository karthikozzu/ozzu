create function trg_reward_claims_enforce_caps() returns trigger
    language plpgsql
as
$$
DECLARE
    v_max_total integer;
    v_max_user integer;
    v_total_claims integer;
    v_user_claims integer;
BEGIN
    SELECT max_total_claims, max_claims_per_user
    INTO v_max_total, v_max_user
    FROM reward_campaigns
    WHERE id = NEW.reward_campaign_id;

    IF v_max_user IS NOT NULL THEN
        SELECT count(*) INTO v_user_claims
        FROM reward_claims
        WHERE reward_campaign_id = NEW.reward_campaign_id
          AND user_id = NEW.user_id;

        IF v_user_claims >= v_max_user THEN
            RAISE EXCEPTION
                'User % has reached max_claims_per_user % for reward_campaign %',
                NEW.user_id, v_max_user, NEW.reward_campaign_id
                USING ERRCODE = '23514';
        END IF;
    END IF;

    IF v_max_total IS NOT NULL THEN
        SELECT count(*) INTO v_total_claims
        FROM reward_claims
        WHERE reward_campaign_id = NEW.reward_campaign_id;

        IF v_total_claims >= v_max_total THEN
            RAISE EXCEPTION
                'Reward campaign % has reached max_total_claims %',
                NEW.reward_campaign_id, v_max_total
                USING ERRCODE = '23514';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function trg_reward_claims_enforce_caps() owner to postgres;

