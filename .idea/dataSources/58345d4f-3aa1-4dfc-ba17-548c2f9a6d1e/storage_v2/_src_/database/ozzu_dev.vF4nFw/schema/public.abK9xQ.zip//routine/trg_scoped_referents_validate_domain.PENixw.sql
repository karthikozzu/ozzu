create function trg_scoped_referents_validate_domain() returns trigger
    language plpgsql
as
$$
DECLARE v_event_domain uuid;
BEGIN
    SELECT e.domain_id INTO v_event_domain FROM events e WHERE e.id = NEW.event_id;
    IF v_event_domain IS NULL THEN
        RAISE EXCEPTION 'Invalid event_id %', NEW.event_id USING ERRCODE = '23503';
    END IF;

    IF NEW.domain_id <> v_event_domain THEN
        RAISE EXCEPTION
            'scoped_referents.domain_id % does not match events.domain_id % for event_id %',
            NEW.domain_id, v_event_domain, NEW.event_id
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END$$;

alter function trg_scoped_referents_validate_domain() owner to postgres;

