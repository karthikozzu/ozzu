create function trg_event_lounges_validate_domain() returns trigger
    language plpgsql
as
$$
DECLARE v_event_domain uuid;
    DECLARE v_lounge_domain uuid;
BEGIN
    SELECT e.domain_id INTO v_event_domain FROM events e WHERE e.id = NEW.event_id;
    IF v_event_domain IS NULL THEN
        RAISE EXCEPTION 'Invalid event_id %', NEW.event_id USING ERRCODE = '23503';
    END IF;

    SELECT l.domain_id INTO v_lounge_domain FROM lounges l WHERE l.id = NEW.lounge_id;
    IF v_lounge_domain IS NULL THEN
        RAISE EXCEPTION 'Invalid lounge_id %', NEW.lounge_id USING ERRCODE = '23503';
    END IF;

    IF NEW.domain_id <> v_event_domain THEN
        RAISE EXCEPTION
            'event_lounges.domain_id % does not match events.domain_id % for event_id %',
            NEW.domain_id, v_event_domain, NEW.event_id
            USING ERRCODE = '23514';
    END IF;

    IF NEW.domain_id <> v_lounge_domain THEN
        RAISE EXCEPTION
            'event_lounges.domain_id % does not match lounges.domain_id % for lounge_id %',
            NEW.domain_id, v_lounge_domain, NEW.lounge_id
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END$$;

alter function trg_event_lounges_validate_domain() owner to postgres;

