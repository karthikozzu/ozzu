create function trg_wager_card_bindings_validate_domain() returns trigger
    language plpgsql
as
$$
DECLARE
  v_wager_event_id uuid;
  v_wager_domain_id uuid;
  v_event_domain_id uuid;
  v_sr_domain_id uuid;
  v_player_domain uuid;
  v_team_domain uuid;
BEGIN
  -- Resolve wager event + domain via wager_card
  SELECT w.event_id, w.domain_id
    INTO v_wager_event_id, v_wager_domain_id
  FROM wager_cards wc
  JOIN wagers w ON w.id = wc.wager_id
  WHERE wc.id = NEW.wager_card_id;

  IF v_wager_event_id IS NULL OR v_wager_domain_id IS NULL THEN
    RAISE EXCEPTION 'Invalid wager_card_id %, cannot resolve wager/event/domain',
      NEW.wager_card_id USING ERRCODE = '23503';
  END IF;

  SELECT e.domain_id INTO v_event_domain_id FROM events e WHERE e.id = v_wager_event_id;
  IF v_event_domain_id IS NULL THEN
    RAISE EXCEPTION 'Cannot resolve event_id % from wager_card_id %',
      v_wager_event_id, NEW.wager_card_id USING ERRCODE = '23503';
  END IF;

  IF v_event_domain_id <> v_wager_domain_id THEN
    RAISE EXCEPTION
      'Wager domain_id % does not match event domain_id % (event_id %)',
      v_wager_domain_id, v_event_domain_id, v_wager_event_id
      USING ERRCODE = '23514';
  END IF;

  -- If scoped referent used: its domain must match
  IF NEW.scoped_referent_id IS NOT NULL THEN
    SELECT sr.domain_id INTO v_sr_domain_id
    FROM scoped_referents sr
    WHERE sr.id = NEW.scoped_referent_id;

    IF v_sr_domain_id IS NULL THEN
      RAISE EXCEPTION 'Invalid scoped_referent_id %', NEW.scoped_referent_id
        USING ERRCODE = '23503';
    END IF;

    IF v_sr_domain_id <> v_wager_domain_id THEN
      RAISE EXCEPTION
        'Scoped referent domain_id % does not match wager/event domain_id %',
        v_sr_domain_id, v_wager_domain_id
        USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
  END IF;

  -- Direct picks: player/team domain must match
  IF NEW.player_id IS NOT NULL THEN
    SELECT p.domain_id INTO v_player_domain FROM players p WHERE p.id = NEW.player_id;
    IF v_player_domain IS NULL THEN
      RAISE EXCEPTION 'Invalid player_id %', NEW.player_id USING ERRCODE = '23503';
    END IF;
    IF v_player_domain <> v_wager_domain_id THEN
      RAISE EXCEPTION
        'Picked player domain_id % does not match wager/event domain_id %',
        v_player_domain, v_wager_domain_id
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF NEW.team_id IS NOT NULL THEN
    SELECT t.domain_id INTO v_team_domain FROM teams t WHERE t.id = NEW.team_id;
    IF v_team_domain IS NULL THEN
      RAISE EXCEPTION 'Invalid team_id %', NEW.team_id USING ERRCODE = '23503';
    END IF;
    IF v_team_domain <> v_wager_domain_id THEN
      RAISE EXCEPTION
        'Picked team domain_id % does not match wager/event domain_id %',
        v_team_domain, v_wager_domain_id
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END$$;

alter function trg_wager_card_bindings_validate_domain() owner to postgres;

