create function trg_auto_join_user_to_default_lounges() returns trigger
    language plpgsql
as
$$
BEGIN
  -- Skip system user (identified by provider + provider_user_id)
  IF NEW.provider = 'EMAIL' AND NEW.provider_user_id = 'ozzu_system' THEN
    RETURN NEW;
  END IF;

  INSERT INTO lounge_memberships (
    id, lounge_id, user_id, role, status, invited_by_user_id, joined_at, internal_properties, created_at, updated_at
  )
  SELECT
    gen_random_uuid(),
    l.id,
    NEW.id,
    'MEMBER',
    'ACTIVE',
    NULL,
    now(),
    jsonb_build_object('autoJoined', true, 'seedVersion','v1'),
    now(),
    now()
  FROM lounges l
  WHERE COALESCE((l.internal_properties->>'autoJoin')::boolean, false) = true
  ON CONFLICT (lounge_id, user_id) DO NOTHING;

  RETURN NEW;
END;
$$;

alter function trg_auto_join_user_to_default_lounges() owner to postgres;

