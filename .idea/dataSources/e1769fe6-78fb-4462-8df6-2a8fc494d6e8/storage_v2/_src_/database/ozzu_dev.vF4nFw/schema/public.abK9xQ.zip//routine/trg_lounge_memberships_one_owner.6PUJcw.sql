create function trg_lounge_memberships_one_owner() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.role = 'OWNER' THEN
    IF EXISTS (
      SELECT 1
      FROM lounge_memberships lm
      WHERE lm.lounge_id = NEW.lounge_id
        AND lm.role = 'OWNER'
        AND lm.id <> COALESCE(NEW.id, gen_random_uuid()) -- safe for inserts
        AND lm.status <> 'REMOVED'
    ) THEN
      RAISE EXCEPTION 'Only one OWNER allowed per lounge (lounge_id=%)', NEW.lounge_id
        USING ERRCODE = '23514';
    END IF;

    -- owners should generally be ACTIVE (enforce if you want strict)
    IF NEW.status IN ('REMOVED','BANNED') THEN
      RAISE EXCEPTION 'OWNER cannot be REMOVED/BANNED (lounge_id=%)', NEW.lounge_id
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

alter function trg_lounge_memberships_one_owner() owner to postgres;

