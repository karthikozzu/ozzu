create function trg_scoped_referents_validate_participants() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.player_id IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM event_participants ep
      WHERE ep.event_id = NEW.event_id AND ep.player_id = NEW.player_id
    ) THEN
      RAISE EXCEPTION
        'Scoped referent player_id % is not an event participant for event_id %',
        NEW.player_id, NEW.event_id
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF NEW.team_id IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM event_participants ep
      WHERE ep.event_id = NEW.event_id AND ep.team_id = NEW.team_id
    ) THEN
      RAISE EXCEPTION
        'Scoped referent team_id % is not an event participant for event_id %',
        NEW.team_id, NEW.event_id
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END$$;

alter function trg_scoped_referents_validate_participants() owner to postgres;

