create function trg_lounge_memberships_set_times() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.updated_at := now();

  -- If transitioning to ACTIVE and joined_at is empty -> set joined_at
  IF (TG_OP = 'INSERT' AND NEW.status = 'ACTIVE' AND NEW.joined_at IS NULL) THEN
    NEW.joined_at := now();
  ELSIF (TG_OP = 'UPDATE') THEN
    IF (OLD.status IS DISTINCT FROM NEW.status) THEN
      IF NEW.status = 'ACTIVE' AND NEW.joined_at IS NULL THEN
        NEW.joined_at := now();
      END IF;

      IF NEW.status IN ('REMOVED','BANNED') AND NEW.left_at IS NULL THEN
        NEW.left_at := now();
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

alter function trg_lounge_memberships_set_times() owner to postgres;

