create function trg_wager_card_bindings_validate_card_type() returns trigger
    language plpgsql
as
$$
DECLARE
  v_wc_type_id uuid;
  v_binding_type_id uuid;
BEGIN
  SELECT wc.wager_card_type_id INTO v_wc_type_id
  FROM wager_cards wc
  WHERE wc.id = NEW.wager_card_id;

  IF v_wc_type_id IS NULL THEN
    RAISE EXCEPTION 'Invalid wager_card_id %, cannot resolve wager_card_type_id',
      NEW.wager_card_id
      USING ERRCODE = '23503';
  END IF;

  SELECT wctb.wager_card_type_id INTO v_binding_type_id
  FROM wager_card_type_bindings wctb
  WHERE wctb.id = NEW.wager_card_type_binding_id;

  IF v_binding_type_id IS NULL THEN
    RAISE EXCEPTION 'Invalid wager_card_type_binding_id %, cannot resolve wager_card_type_id',
      NEW.wager_card_type_binding_id
      USING ERRCODE = '23503';
  END IF;

  IF v_wc_type_id <> v_binding_type_id THEN
    RAISE EXCEPTION
      'wager_card_type_binding_id % belongs to wager_card_type_id %, but wager_card_id % is of wager_card_type_id %',
      NEW.wager_card_type_binding_id, v_binding_type_id, NEW.wager_card_id, v_wc_type_id
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END$$;

alter function trg_wager_card_bindings_validate_card_type() owner to postgres;

