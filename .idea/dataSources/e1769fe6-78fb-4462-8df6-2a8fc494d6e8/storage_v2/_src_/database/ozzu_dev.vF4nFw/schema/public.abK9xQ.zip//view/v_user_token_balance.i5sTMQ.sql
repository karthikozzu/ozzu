create view v_user_token_balance(user_id, balance) as
SELECT user_id,
       COALESCE(sum(amount), 0::bigint) AS balance
FROM token_ledger
GROUP BY user_id;

alter table v_user_token_balance
    owner to postgres;

